from process.file_types import whichType
from process.exit import ExitCodes
