# 24-10-23 8pm Meeting Notes 
## Topics
- familiarise yourself with github page
- fuzzer initial:
    - using python as language with pwntools
    - research each file type (json, csv)
    - research harness
- figure out what you want to work on based on research
- start on helper functions if able
## Present Members
- Liam
- Ziqi
- Shafi

## Next Meeting - Thursday (26-10-23) 9-10pm ish

# 26-10-23 10pm Meeting
## Topics
- went through each section
- mutators
    - how they should function for json
    - how they should function for csv
    - e.g. bit flips
- harness
- will go over more thoroughly with everyone in next meeting
## Present Members
- ?

## Next Meeting - ideally, next meeting tomorrow (27/10/23)


